package com.github.fagner.crud;


import java.math.BigDecimal;

public class CadastrarProdutoDTO {
    
    public String nome;

    public BigDecimal valor;


}
